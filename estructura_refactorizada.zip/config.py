class Config:
    SECRET_KEY = 'alkimyk_clave_segura'
    SQLALCHEMY_DATABASE_URI = 'sqlite:///alkimyk.db'
    SQLALCHEMY_TRACK_MODIFICATIONS = False