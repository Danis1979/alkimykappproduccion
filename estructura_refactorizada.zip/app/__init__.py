from flask import Flask
from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()

def create_app():
    app = Flask(__name__)
    app.secret_key = 'alkimyk_clave_segura'
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///alkimyk.db'
    app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

    db.init_app(app)

    from app.routes.auth_routes import auth_bp
    from app.routes.planificacion_routes import planificacion_bp

    app.register_blueprint(auth_bp)
    app.register_blueprint(planificacion_bp)

    return app