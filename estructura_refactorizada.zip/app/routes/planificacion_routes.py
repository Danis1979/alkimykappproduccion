from flask import Blueprint, render_template

planificacion_bp = Blueprint('planificacion', __name__)

@planificacion_bp.route('/')
def home():
    return render_template('index.html')